describe file('/etc/opt/microsoft/mdatp/mdatp_onboard.json') do
    it { should exist }
    it { should be_file }
end