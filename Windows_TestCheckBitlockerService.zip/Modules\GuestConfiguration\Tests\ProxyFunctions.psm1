Function Get-AzPolicyDefinition {}

Function Get-AzPolicySetDefinition {}